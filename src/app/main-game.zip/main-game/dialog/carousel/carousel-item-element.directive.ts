import { Directive } from '@angular/core';

@Directive({
  selector: '.carousel-item',
})
export class CarouselItemElementDirective {}